import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class UnitInfo {
    private String name;
    private int wounds;
    private int modifyToHit;
    private int modifyToWound;

    public UnitInfo(String name, int wounds, int modifyToHit, int modifyToWound) {
        this.name = name;
        this.wounds = wounds;
        this.modifyToHit = modifyToHit;
        this.modifyToWound = modifyToWound;
    }

    public void printToFile(String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            writer.println(name + ", " + wounds + ", " + modifyToHit + ", " + modifyToWound);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    public String getName() {
        return name;
    }

    public int getWounds() {
        return wounds;
    }

    public int getModifyToHit() {
        return modifyToHit;
    }

    public int getModifyToWound() {
        return modifyToWound;
    }
    public void setWounds(int wounds) {
    	this.wounds = wounds;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try (PrintWriter writer = new PrintWriter("unit_info.txt")) {
            do {
                System.out.print("Enter unit name: ");
                String name = scanner.nextLine();

                System.out.print("Enter number of wounds: ");
                int wounds = scanner.nextInt();

                System.out.print("Enter modify to hit: ");
                int modifyToHit = scanner.nextInt();

                System.out.print("Enter modify to wound: ");
                int modifyToWound = scanner.nextInt();

                UnitInfo unit = new UnitInfo(name, wounds, modifyToHit, modifyToWound);
                unit.printToFile("unit_info.txt");

                System.out.println("Unit information written to file.");

                System.out.print("Do you want to enter another unit? (yes/no): ");
                scanner.nextLine(); // Consume the newline character
            } while ("yes".equalsIgnoreCase(scanner.nextLine()));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }

        System.out.println("Program terminated.");
    }
}
