import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class WoundCalculator {

    public static void main(String[] args) {
        // Read all units from the file
        List<UnitInfo> units = readAllUnitsFromFile("unit_info.txt");

        // Display available units
        System.out.println("Available Units:");
        for (int i = 0; i < units.size(); i++) {
            System.out.println((i + 1) + ". " + units.get(i).getName());
        }

        // Ask the user to choose a unit
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of the unit to attack: ");
        int chosenUnitIndex = scanner.nextInt();

        // Validate user input
        if (chosenUnitIndex < 1 || chosenUnitIndex > units.size()) {
            System.err.println("Invalid unit selection. Exiting program.");
            return;
        }

        // Get the chosen unit
        UnitInfo unit = units.get(chosenUnitIndex - 1);

        // Simulation loop
        while (unit.getWounds() > 0) {
            // Display unit information
            System.out.println("Unit: " + unit.getName());
            System.out.println("Modifier to Hit: " + unit.getModifyToHit());
            System.out.println("Modifier to Wound: " + unit.getModifyToWound());

            // Ask for dice type and number to hit
            System.out.print("Enter dice type (e.g., 6): ");
            int diceType = scanner.nextInt();
            System.out.print("Enter number of dice to hit: ");
            int numberOfDiceToHit = scanner.nextInt();

            // Roll the dice to hit
            int hits = rollDice(numberOfDiceToHit, diceType, unit.getModifyToHit());

            // Ask for the amount that passed
            System.out.print("Enter the number of hits that passed: ");
            int passedHits = scanner.nextInt();

            // Reroll for wounds
            int wounds = rollDice(passedHits, diceType, unit.getModifyToWound());

            // Ask for damage
            System.out.print("Enter the damage value: ");
            int damage = scanner.nextInt();

            // Update wounds
            unit.setWounds(unit.getWounds() - damage * passedHits);

            // Display current state
            System.out.println("Remaining Wounds: " + unit.getWounds());

            // Check if the unit is dead
            if (unit.getWounds() <= 0) {
                System.out.println("Unit is dead.");
                break;
            }

            // Repeat the simulation
        }

        // Close the scanner
        scanner.close();
        System.out.println("Program terminated.");
    }

    private static int rollDice(int numberOfDice, int diceType, int modifier) {
        Random random = new Random();
        int total = 0;
        for (int i = 0; i < numberOfDice; i++) {
            int roll = random.nextInt(diceType) + 1; // Roll the dice
            total += roll;
        }
        return total + modifier;
    }

    private static List<UnitInfo> readAllUnitsFromFile(String fileName) {
        List<UnitInfo> units = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] info = line.split(", ");

                if (info.length >= 4) {
                    String name = info[0];
                    int wounds = Integer.parseInt(info[1]);
                    int modifyToHit = Integer.parseInt(info[2]);
                    int modifyToWound = Integer.parseInt(info[3]);

                    units.add(new UnitInfo(name, wounds, modifyToHit, modifyToWound));
                } else {
                    System.err.println("Error: Insufficient data in the file.");
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        }

        return units;
    }
}
