import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class UnitInfoTest {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test
    public void testPrintToFile() throws IOException {
        // Arrange
        String expectedOutput = "TestUnit, 10, 2, 3";

        // Create a temporary file in the temporary folder
        String tempFileName = tempFolder.getRoot().getPath() + "/temp_unit_info.txt";
        UnitInfo unit = new UnitInfo("TestUnit", 10, 2, 3);

        // Act
        unit.printToFile(tempFileName);

        // Assert
        try (BufferedReader reader = new BufferedReader(new FileReader(tempFileName))) {
            String actualOutput = reader.readLine();
            assertEquals(expectedOutput, actualOutput);
        }
    }
}

